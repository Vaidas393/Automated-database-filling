
<?php
include 'connection.php';

function addData() {
  $start = '2019-01-01';
  $end = '2019-02-01';
  $currentDate = strtotime($start);
  // i will be used as id in periods table
  $i = 0;
  while($currentDate <= strtotime($end)){
      $i++;
      $formatted = date("Y-m-d h:i:s", $currentDate);
      // echo $formatted, '<br>';
      // Creating random integers for point and period ids
      $period = rand(1,2977);
      $point = rand(1,2977);
      // creating random S,M letters for source
      $sourceRandom = rand(0,1);
      $a=array("S","M");
      $random_keys=array_rand($a,2);
      $source=$a[$random_keys[$sourceRandom]];
      // Creating random integers for point and period idsto fill rest of the table
      $rw =rand(1,1000)/10;
      $rx =rand(1,1000)/10;
      $ry =rand(1,1000)/10;
      $rz =rand(1,1000)/10;
      // setting date change value to 15 minutes
      $currentDate = strtotime("+15 minute", $currentDate);
      // sql queries to fill both tables at the same time
      $con = mysqli_connect("localhost","username","password","dbname");
      $query = "INSERT INTO periods (id,period_from) VALUES ($i,'$formatted')";
      $dataQuery = "INSERT INTO data (period_id, point_id, source, rw, rx, ry, rz) VALUES ($period, $point, '$source', $rw, $rx, $ry, $rz)";
      $query_run = mysqli_query($con, $query);
      $query_run = mysqli_query($con, $dataQuery);
  }
}

if(array_key_exists('testas',$_POST)){
   addData();
}

function deleteData() {
  $deleteData = "DELETE FROM data";
  $deletePeriods = "DELETE FROM periods";
  $con = mysqli_connect("localhost","username","password","dbname");
  $con->query($deleteData);
  $con->query($deletePeriods);
}

if(array_key_exists('test',$_POST)){
   deleteData();
}
// Query to display table
$sumQuery="SELECT id, period_from, period_id, source, (rw+rz) as 'total', (ry+rz) as 'secondTotal' FROM periods, data WHERE point_id = id GROUP BY period_from";
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <title></title>
  </head>
  <body>
    <section>

      <h1>Automated database filling and automated API testing</h1>
      <div class="links">
        <form method="post">
          <button type="submit" name="testas" >Generate database data (please be patient, generating lots of data :) )</button>
        </form>
        <form method="post">
          <button class="removeBtn" type="submit" name="test" >Remove data</button>
        </form>
     </div>

      <div class="tbl-header">
        <table cellpadding="0" cellspacing="0" border="0">
          <thead>
            <tr>
              <th>Id</th>
              <th>Period_from</th>
              <th>Period id</th>
              <th>Source</th>
              <th>RW + RZ total</th>
              <th>RY + RZ total</th>
            </tr>
          </thead>
        </table>
      </div>
      <div class="tbl-content">
        <table cellpadding="0" cellspacing="0" border="0">
          <tbody>
            <?php foreach ($con->query($sumQuery) as $row) { ?>
            <tr>
              <td><?php echo htmlspecialchars($row["id"]) ?></td>
              <td><?php echo htmlspecialchars($row["period_from"]) ?></td>
              <td><?php echo htmlspecialchars($row["period_id"]) ?></td>
              <td><?php echo htmlspecialchars($row["source"]) ?></td>
              <td><?php echo htmlspecialchars($row["total"]) ?></td>
              <td><?php echo htmlspecialchars($row["secondTotal"]) ?></td>
            </tr>
          <?php } ?>
          </tbody>
        </table>
      </div>
    </section>
    <script src="scrool.js"></script>

  </body>
</html>
